IMPORTANT: The "Beginner Mod Pack" is also required for this to work. However, you can delete the "RFB_PAcker" folder that it will install and disregard the unpacking instructions in the README. 



Please follow these steps to correctly install the Advanced Modding pack:


1) Extract and install the Installer
2) Find the folder on your computer called "RFB_mod" (it is at C:\RFB_Mod).
3) Open it and click on "PackerWin32_v1". 
4) Select "Unpack"
5) We are going to run four operations now. 
6) Please enter the following information into the correct field:

7)

Source: C:\Program Files\Deep Silver\Rush for Berlin\main.pak
Destination: C:\RFB_Mod\MAIN

8) Hit "Unpack" and wait till it is done.

9)

Enter these lines in the Packer:

Source: C:\Program Files\Deep Silver\Rush for Berlin\main2.pak
Destination: C:\RFB_Mod\MAIN

10) Hit "Unpack" and wait till it is done.

11)

Enter these lines in the Packer:

Source: C:\Program Files\Deep Silver\Rush for Berlin\system.pak
Destination: C:\RFB_Mod\MAIN

12) Hit "Unpack" and wait till it is done. 
 
Source: C:\Program Files\Deep Silver\Rush for Berlin\en.pak
Destination: C:\RFB_Mod\EN

13) Hit "Unpack" and wait till it is done.

14) You now have a working modding system for Rush for Berlin

15) Note: If the Packer does not function because the source is wrong, find the source manually by using the "Open" button on the Packer. 


How to use:

You can alter any file in the "Main" or in the "EN" folder. To play with these changes, use the RushforBerlin.exe in this RFB_mod folder. You can also add modified units etc. to maps using the Editor in this RFB_mod folder. 



Should you wish to distribute your changes to other players, please follow the instructions given in the readme found at C:\RFB_mod\docs\RFB Packer Tutorial_v2.doc



Enjoy!!!!!!!!!!!!!












