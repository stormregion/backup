Hey folks,

Here is a simpler better method of using some of the modding tools with Rush for Berlin. 


To keep this as simple as possible, I will explain only the most basic issues associated with this package. To begin with, here is what you can and cannot do with this package:

What you can do:

i)   Make maps with the Editor
ii)  Alter existing maps with the Editor
iii) Play RFB with a community made modding pak
iv)  Play custom Multiplayer maps
v)   Play custom Single Player Maps (but only through the "Test-in-Game" feature of the Editor. A future patch will allow you to play any custom SP maps as part of the campaign).

What you cannot do (can only be done with the Advanced set):

i)  Make mod paks
ii) Use modified units in the Editor. 


Installation Instructions:

1) Extract this readme and the install file onto your computer. Anywhere you like. 
2) Read this entire README to ensure you have no problems.
3) Click on the Installer and Install it. 
4) You will now have more files in your game directory. You will also have a new folder on your computer called "RFB_packer". This folder is located at C:\RFB_packer. 
5) In your game folder, you need to find a file called "game.ini". when you have found it, open it with Notepad and look at the contents. 
6) The contents could look like this: 

[Paths]
Search = 
Search Base =
Home = 
Locale = us

[Editor]
Right Panel = 0


[Debug]
Debug Level = 0

VERY IMPORTANT: If they DO look like this, proceed to STEP 7. If they DO NOT look exactly like this, then come to the forums boards at www.stormregion.com and copy/paste the contents of your game.ini file into a post and let us know you have a different game.ini from the one mentioned here in the readme. 

7) Again, if you have even one letter or number different than the above (STEP 6) DO NOT follow these instructions: 

Erase everything in your game.ini file and copy/paste this into the game.ini file: 


[Paths]
Search = 
Search Base =
Home = C:\Program Files\Deep Silver\Rush for Berlin\
Locale = us

[Editor]
Right Panel = 0
Test in game = C:\Program Files\Deep Silver\Rush for Berlin\rushforberlin.exe 

[Debug]
Debug Level = 0


8) Now everything should work. 


HOW TO USE:

1) You now have an Editor that you can use to make maps. Any Single Player maps that you make should be saved in the "maps" folder that was created in your game folder. For Multiplayer maps, they should be placed in the "multimaps" folder in the correct folder. In other words, Risk maps should be placed in the "RISK" folder. There is also a naming convention that you should use when naming your MP maps. A map's name should be as follows: (N) Nameofmap.map. The "(N)" is the number of players for that map. For instance, a 4 player map could be called: (4) mymap.map. Also, if you put the map in the RISK folder, it will appear in Multiplayer under the RISK category, for instance. Lastly, if you see any error messages click on "Ignore All" or "OK". 

2) You have a folder named "mods". When another player makes a modded pak file and you download it, you should put it in this folder. To play with this modded file, you do not use the normal exe to start the game, instead you use the "RushForBerlin_mod.exe" to start your game of Rush for Berlin. 


FOR INTERMEDIATE USERS:

Some of you have mentioned wanting to alter the existing maps in the game. This is done outside of the game folder. REPEAT: Do not do any of these steps and involve the game itself. Even if you put a single one of the files in this process into the folder where you installed your game, you could mess up the entire game. So this process should be done in an entirely different location than the game. For this purpose, we have created a seperate set of folders on your computer. You can find this folder at C:\RFB_packer. Follow these steps:

1) Click on "PackerWin32.exe" to open the program (the packer). 
2) Set the packer to "Unpack"
3) Set the "Destination" as: "c:\RFB_packer\Unpack into this Main folder - Not into the game\MAIN" (Note, remove the "quotes" if you copy paste this into the packer). 
4) Now you have established where the files that are extracted from the game will go. They will go to: "c:\RFB_packer\Unpack into this Main folder - Not into the game\MAIN" so when you are finished with these instructions, look there for them. 
5) Now we need to choose the files to unpack. The Destination will always stay the same. But the "Source" must change. The "Source" is the pak files that were installed with your game. We need to select three of these pak files to unpack. In the packer program, click on the "Open" icon and find the following file on your computer: "main.pak". It is in the folder for your Rush for Berlin game. When you have found it, select it and press "OK". Now you should have set your "Source" in the packer program. 
6) In the packer program, click on "Unpack". The program will run and you will have the files in "main.pak" opened into your destination. 
7) When you have finished with this "main.pak" file, continue with step 8
8) Do not change the "Destination"
9) Click on the "Open" icon for the "Source" again. This time choose the "main2.pak". Then hit "OK".
10) In the packer program, click on "Unpack".
11) Next is the "system.pak" file. Continue with step 12
12) Do not change the "Destination"
13) Click on the "Open" icon for the "Source" again. This time choose the "system.pak". Then hit "OK".
14) In the packer program, click on "Unpack".
15) You now have a majority of the games files unpacked on your computer. But the only thing you want are the maps files. You want to be able to open the official multiplayer and single player maps in the Editor, right? Well the map files are now there in the Destination. So find them. 
16) Once you have found them, you have found what you want. You do not need the other files as they only take up space on your computer. So keep what you want to keep (the map files) and delete what you do not want to keep. Just to be sure, map files have the following extension: ".map".
17) Open the editor and open the map files to look at them. 


